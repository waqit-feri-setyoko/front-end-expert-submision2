import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';
import button from './feature/button';
import home from './template/home';

//Menu
button();

//Load Post
home();